package org.spring.springboot.result;

/**
 * 错误码接口
 *
 * Created by bysocket on 13/03/2017.
 */
public interface ErrorInfoInterface {
    String getCode();
    String getMessage();
}
